About the program

    This program reads controller inputs and translates them into keyboard and mouse functions.

Installation


How to use it

    After installing plug your controller into the device and run the program as an administrator 
Configurations
    